# Lil Buddy ProGuard Rules
-keep class com.lilbuddy.companion.model.** { *; }
