package com.lilbuddy.companion.model

/**
 * Message Model supporting Persian RTL, English LTR, and Emoji Unicode sequences.
 */
data class LilBuddyMessage(
    val id: String,
    val characterId: CharacterId,
    val textFa: String,
    val textEn: String,
    val emotion: CharacterEmotion,
    val emoji: String,
    val prop: String? = null,
    val isCustom: Boolean = false
)
