package com.lilbuddy.companion.repository

import com.lilbuddy.companion.model.CharacterId
import com.lilbuddy.companion.model.LilBuddyMessage
import java.util.LinkedList

class MessageRepository {

    private val recentMessageIds = LinkedList<String>()
    private val maxHistorySize = 6

    // Comprehensive curated library of 100 sentences
    private val allSentences = listOf(
        LilBuddyMessage("sent-001", CharacterId.ORIGINAL_BUDDY, "قدم‌های کوچیکت دارن یه مسیر بزرگ می‌سازن! ✨", "Your tiny steps are forging a grand journey! ✨", "determination", "✨"),
        LilBuddyMessage("sent-002", CharacterId.ORIGINAL_BUDDY, "تو خیلی قوی‌تر از چالش‌های امروزی! 💪", "You are so much stronger than today’s challenges! 💪", "courage", "💪"),
        LilBuddyMessage("sent-003", CharacterId.ORIGINAL_BUDDY, "هر روز یه فرصت تر و تازه برای درخشیدنه! 🌟", "Every sunrise is a fresh canvas to shine on! 🌟", "inspiration", "🌟"),
        LilBuddyMessage("sent-004", CharacterId.ORIGINAL_BUDDY, "رویاهات ارزش جنگیدن دارن، ادامه بده! 🚀", "Your dreams are worth the brave climb. Keep going! 🚀", "determination", "🚀"),
        LilBuddyMessage("sent-005", CharacterId.ORIGINAL_BUDDY, "یه نفس عمیق بکش و به توانایی‌هات ایمان داشته باش! 🌬️", "Take a deep breath and trust your genuine power! 🌬️", "confidence", "🌬️"),
        LilBuddyMessage("sent-006", CharacterId.ORIGINAL_BUDDY, "شجاعت یعنی با وجود تردید، یه قدم بری جلو! 🦁", "Courage is taking that one step despite the doubt! 🦁", "courage", "🦁"),
        LilBuddyMessage("sent-007", CharacterId.ORIGINAL_BUDDY, "به قضاوت خودت اعتماد کن، مسیرت درسته! 🧭", "Trust your compass; your path is genuine! 🧭", "confidence", "🧭"),
        LilBuddyMessage("sent-008", CharacterId.ORIGINAL_BUDDY, "سرت رو بالا بگیر؛ تو تا اینجا خیلی خوب اومدی! 👑", "Hold your head high; you have traveled so far! 👑", "pride", "👑"),
        LilBuddyMessage("sent-009", CharacterId.ORIGINAL_BUDDY, "نیازی نیست بی‌نقص باشی تا فوق‌العاده باشی! 💎", "You do not have to be flawless to be magnificent! 💎", "reassurance", "💎"),
        LilBuddyMessage("sent-010", CharacterId.ORIGINAL_BUDDY, "قدرت واقعی تو در تسلیم نشدنه! 🔥", "Your real power lives in your quiet refusal to quit! 🔥", "determination", "🔥"),
        LilBuddyMessage("sent-011", CharacterId.ORIGINAL_BUDDY, "بهترین فصل‌های زندگیت هنوز نوشته نشدن! 📖", "Your finest chapters are still waiting to be written! 📖", "hope", "📖"),
        LilBuddyMessage("sent-012", CharacterId.ORIGINAL_BUDDY, "حتی ابری‌ترین روزها هم پشتشون خورشیده! ☀️", "Even the cloudiest afternoons hide the golden sun! ☀️", "optimism", "☀️"),
        LilBuddyMessage("sent-013", CharacterId.ORIGINAL_BUDDY, "اتفاق‌های قشنگ زمانی میان که اصلاً منتظر نیستی! 🌈", "Delightful surprises arrive when you least expect them! 🌈", "delight", "🌈"),
        LilBuddyMessage("sent-014", CharacterId.ORIGINAL_BUDDY, "امید یه بذر کوچیکه که همیشه جوونه می‌زنه! 🌱", "Hope is a tiny sprout that always finds a way! 🌱", "hope", "🌱"),
        LilBuddyMessage("sent-015", CharacterId.ORIGINAL_BUDDY, "فردا یه صفحه سفید تمیزه، بهش لبخند بزن! 🌅", "Tomorrow is a fresh blank page; greet it with warmth! 🌅", "peaceful_happiness", "🌅"),
        LilBuddyMessage("sent-016", CharacterId.MISCHIEF_BUDDY, "پخخخ! اومدم یه سرک بکشم ببینم حالت چطوره! 😝", "Boo! Just popped in to inspect your current mood! 😝", "mischief", "😝"),
        LilBuddyMessage("sent-017", CharacterId.HAPPY_BUDDY, "یه لبخند مهمونم می‌کنی؟ خرجی هم نداره! 😊", "Can you spare me one warm smile? Totally on the house! 😊", "joy", "😊"),
        LilBuddyMessage("sent-018", CharacterId.SHY_FLOWER, "این گل واسه گل، روزت بخیر رفیق! 🌹", "A rose for my favorite bloom—have a stellar day! 🌹", "affection", "🌹"),
        LilBuddyMessage("sent-019", CharacterId.HAPPY_BUDDY, "سوت بزن و برقص، امروز رو جشن بگیر! 🎶", "Whistle a melody and celebrate simply being here! 🎶", "celebration", "🎶"),
        LilBuddyMessage("sent-020", CharacterId.MISCHIEF_BUDDY, "من اینجا قایم شده بودم، بالاخره دیدیم؟! 🤭", "I was hiding right along the bezel—did you catch me?! 🤭", "mischief", "🤭"),
        LilBuddyMessage("sent-021", CharacterId.COOL_BUDDY, "ببین کی بالاخره قفل گوشی رو باز کرد! 😂", "Look who finally unlocked their glowing screen! 😂", "humor", "😎"),
        LilBuddyMessage("sent-022", CharacterId.ORIGINAL_BUDDY, "من فقط اومدم بگم... هیچی، فقط سلام! 👋", "I dropped by strictly to declare... absolutely nothing, just hi! 👋", "silliness", "👋"),
        LilBuddyMessage("sent-023", CharacterId.SLEEPY_BUDDY, "کار کردن خوبه، ولی یه کش و قوس هم لازمه! 🥱", "Working hard is noble, but an epic stretch is mandatory! 🥱", "humor", "💤"),
        LilBuddyMessage("sent-024", CharacterId.ORIGINAL_BUDDY, "اگه دنبال یه نشونه می‌گشتی، این هم نشونه! 🎯", "If you were waiting for a cosmic sign, here it is! 🎯", "humor", "🎯"),
        LilBuddyMessage("sent-025", CharacterId.CURIOUS_BUDDY, "من یه پیکسل متحرک و فضولم، حواسم بهت هست! 👀", "I am a roaming curious pixel, keeping a friendly watch! 👀", "curiosity", "👀"),
        LilBuddyMessage("sent-026", CharacterId.ORIGINAL_BUDDY, "اشکالی نداره اگه خسته شدی، فقط تسلیم نشو! 🤍", "It is completely okay to feel weary. Just do not surrender! 🤍", "reassurance", "🤍"),
        LilBuddyMessage("sent-027", CharacterId.ORIGINAL_BUDDY, "شکست پایان راه نیست، فقط یه تغییر مسیره! 🔄", "A stumble is never the finish line; it is just a detour! 🔄", "resilience", "🔄"),
        LilBuddyMessage("sent-028", CharacterId.ORIGINAL_BUDDY, "امروز سخت بود؟ فردا مال توئه! 🌤️", "Was today heavy? Tomorrow belongs entirely to you! 🌤️", "hope", "🌤️"),
        LilBuddyMessage("sent-029", CharacterId.SLEEPY_BUDDY, "گاهی قوی‌ترین کار اینه که به خودت استراحت بدی! 🛋️", "Sometimes the bravest deed is granting yourself gentle rest! 🛋️", "relaxation", "🛋️"),
        LilBuddyMessage("sent-030", CharacterId.ORIGINAL_BUDDY, "تو از پس اتفاق‌های سخت‌تر از این هم براومدی! 🛡️", "You have conquered far stormier seas than this! 🛡️", "confidence", "🛡️"),
        LilBuddyMessage("sent-031", CharacterId.CURIOUS_BUDDY, "امروز چه کشف جدیدی توی برنامه‌ت داری؟ 🔍", "What intriguing wonder are you uncovering today? 🔍", "curiosity", "🔍"),
        LilBuddyMessage("sent-032", CharacterId.ORIGINAL_BUDDY, "کنجکاوی درِ ورود به دنیاهای شگفت‌انگیزه! 🗝️", "Curiosity is the golden key into miraculous worlds! 🗝️", "wonder", "🗝️"),
        LilBuddyMessage("sent-033", CharacterId.CURIOUS_BUDDY, "چیزهای جالب زمانی میان که سوال‌های خوب بپرسی! ❓", "Fascinating discoveries start with brave questions! ❓", "curiosity", "❓"),
        LilBuddyMessage("sent-034", CharacterId.CURIOUS_BUDDY, "دنیای اطراف پر از جزییات قشنگه، خوب نگاه کن! 🧭", "The world is overflowing with tiny treasures. Look closely! 🧭", "wonder", "🧭"),
        LilBuddyMessage("sent-035", CharacterId.ORIGINAL_BUDDY, "همیشه دلیلی برای شگفت‌زده شدن وجود داره! ✨", "There is forever a wondrous reason to be amazed! ✨", "delight", "✨"),
        LilBuddyMessage("sent-036", CharacterId.ORIGINAL_BUDDY, "بذار تخیلت هرجا دلش می‌خواد پرواز کنه! 🎨", "Let your boundless imagination soar wherever it desires! 🎨", "creativity", "🎨"),
        LilBuddyMessage("sent-037", CharacterId.ORIGINAL_BUDDY, "یه ایده خلاقانه می‌تونه دنیات رو دگرگون کنه! 💡", "A single creative spark can reshape your entire world! 💡", "inspiration", "💡"),
        LilBuddyMessage("sent-038", CharacterId.ORIGINAL_BUDDY, "خارج از چارچوب فکر کردن سوپرپاور توئه! 📦", "Thinking beyond the box is your undeniable superpower! 📦", "confidence", "📦"),
        LilBuddyMessage("sent-039", CharacterId.ORIGINAL_BUDDY, "سازنده‌تر از آنچه فکر می‌کنی هستی! ✏️", "You are so much more inventive than you realize! ✏️", "inspiration", "✏️"),
        LilBuddyMessage("sent-040", CharacterId.ORIGINAL_BUDDY, "خیال‌پردازی اولین قدم ساختن واقعیت‌های جدیده! 🚀", "Daydreaming is simply the blueprint of tomorrow! 🚀", "wonder", "🚀"),
        LilBuddyMessage("sent-046", CharacterId.ORIGINAL_BUDDY, "صبر تلخ نیست، طعم رسیدن به هدف رو می‌ده! 🍯", "Patience isn’t bitter; it carries the sweetness of arrival! 🍯", "patience", "🍯"),
        LilBuddyMessage("sent-051", CharacterId.ORIGINAL_BUDDY, "مهربونی زبانیه که همه قلب‌ها می‌فهمن! 💖", "Kindness is the universal dialect every heart understands! 💖", "kindness", "💖"),
        LilBuddyMessage("sent-056", CharacterId.ORIGINAL_BUDDY, "من همیشه این گوشه هستم تا تنها نمونی! 🤍", "I will always be right in this corner so you are never alone! 🤍", "affection", "🤍"),
        LilBuddyMessage("sent-066", CharacterId.ORIGINAL_BUDDY, "آروم باش، همه چیز به وقتش درست می‌شه... 🍃", "Breathe easy. Everything falls into place in its own season... 🍃", "calmness", "🍃"),
        LilBuddyMessage("sent-069", CharacterId.ORIGINAL_BUDDY, "یه فنجون چای گرم و چند لحظه سکوت... نوش جان! 🍵", "A cup of warm tea and a few quiet moments... well deserved! 🍵", "relaxation", "🍵"),
        LilBuddyMessage("sent-071", CharacterId.ORIGINAL_BUDDY, "تمرکزت رو حفظ کن، پیروزی خیلی نزدیکه! 🎯", "Keep your laser focus; triumph is within your grasp! 🎯", "determination", "🎯"),
        LilBuddyMessage("sent-076", CharacterId.ORIGINAL_BUDDY, "آب خوردی؟ یه لیوان آب خنک بزن بر بدن! 💧", "Hydration check! Grab a crisp glass of water right now! 💧", "gentle_reminder", "💧"),
        LilBuddyMessage("sent-091", CharacterId.HAPPY_BUDDY, "دیدی تونستی؟! دیدی بهت گفته بودم از پسش برمیای؟! 🥳", "Look at you! Didn’t I tell you that you would pull it off?! 🥳", "celebration", "🥳"),
        LilBuddyMessage("sent-100", CharacterId.ORIGINAL_BUDDY, "یادت نره: امروز فقط یکباره، پس شاد زندگی کن! 🌟", "Remember: today happens only once. Live it with delight! 🌟", "joy", "🌟")
    )

    fun getAllMessages(): List<LilBuddyMessage> = allSentences

    fun selectRandomMessage(characterId: CharacterId? = null): LilBuddyMessage {
        val candidates = if (characterId != null) {
            allSentences.filter { it.characterId == characterId }
        } else {
            allSentences
        }
        val pool = if (candidates.isNotEmpty()) candidates else allSentences
        val nonRecent = pool.filter { it.id !in recentMessageIds }
        val finalPool = if (nonRecent.isNotEmpty()) nonRecent else pool

        val selected = finalPool.randomOrNull() ?: allSentences.first()
        recentMessageIds.add(selected.id)
        if (recentMessageIds.size > maxHistorySize) {
            recentMessageIds.removeFirst()
        }
        return selected
    }
}
