package com.lilbuddy.companion.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.lilbuddy.companion.data.SettingsRepository
import com.lilbuddy.companion.scheduler.LilBuddyScheduler
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

/**
 * Restores Lil Buddy schedule upon device reboot or package update.
 */
class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED ||
            intent.action == Intent.ACTION_MY_PACKAGE_REPLACED
        ) {
            val pendingResult = goAsync()
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    val settings = SettingsRepository(context).settingsFlow.first()
                    if (settings.isEnabled) {
                        val scheduler = LilBuddyScheduler(context)
                        scheduler.scheduleNextAppearance(settings.intervalMinutes)
                    }
                } finally {
                    pendingResult.finish()
                }
            }
        }
    }
}
