package com.lilbuddy.companion.overlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.lilbuddy.companion.R
import com.lilbuddy.companion.data.SettingsRepository
import com.lilbuddy.companion.model.CharacterId
import com.lilbuddy.companion.model.LilBuddyCharacter
import com.lilbuddy.companion.repository.MessageRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.Random

/**
 * Native Android Overlay Service using WindowManager TYPE_APPLICATION_OVERLAY.
 * Presents the brief 8-second animated companion visit.
 */
class LilBuddyOverlayService : Service() {

    companion object {
        const val ACTION_SHOW_SCHEDULED_BUDDY = "com.lilbuddy.companion.SHOW_BUDDY"
        const val ACTION_SHOW_TEST_BUDDY = "com.lilbuddy.companion.SHOW_TEST_BUDDY"
        const val CHANNEL_ID = "lil_buddy_channel"
        const val NOTIFICATION_ID = 1001
    }

    private var windowManager: WindowManager? = null
    private var overlayContainer: FrameLayout? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + Job())
    private val handler = Handler(Looper.getMainLooper())
    private var dismissRunnable: Runnable? = null
    private var typewriterRunnable: Runnable? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildSilentNotification())

        serviceScope.launch {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this@LilBuddyOverlayService)) {
                stopSelf()
                return@launch
            }

            val settingsRepo = SettingsRepository(this@LilBuddyOverlayService)
            val settings = settingsRepo.settingsFlow.first()

            val characterId = if (settings.isRandomCharacter) {
                CharacterId.values().random()
            } else {
                settings.selectedCharacterId
            }

            val character = LilBuddyCharacter.findById(characterId)
            val messageRepo = MessageRepository()
            val message = messageRepo.selectRandomMessage(characterId)

            val displayEdge = when (settings.preferredEdge) {
                "LEFT" -> "LEFT"
                "RIGHT" -> "RIGHT"
                else -> if (Random().nextBoolean()) "LEFT" else "RIGHT"
            }

            showBuddyOverlay(character, message.textFa, displayEdge, settings.displayDurationSeconds)
        }

        return START_NOT_STICKY
    }

    private fun showBuddyOverlay(
        character: LilBuddyCharacter,
        messageText: String,
        edge: String,
        durationSeconds: Int
    ) {
        removeOverlay()

        val layoutParams = WindowManager.LayoutParams().apply {
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }
            // Do not block touches outside our little character window
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

            format = PixelFormat.TRANSLUCENT
            gravity = if (edge == "LEFT") Gravity.START or Gravity.CENTER_VERTICAL else Gravity.END or Gravity.CENTER_VERTICAL
            x = 0
            y = 0
        }

        val container = FrameLayout(this).apply {
            setPadding(16, 16, 16, 16)
            clipChildren = false
            clipToPadding = false
        }

        // Tap on character/bubble dismisses immediately
        container.setOnClickListener {
            removeOverlay()
            stopSelf()
        }

        // Inner view with character emoji/prop and speech bubble
        val bubbleTextView = TextView(this).apply {
            setBackgroundColor(android.graphics.Color.WHITE)
            setTextColor(android.graphics.Color.parseColor("#0F172A"))
            textSize = 15f
            setPadding(24, 16, 24, 16)
            elevation = 12f
        }

        container.addView(bubbleTextView)
        overlayContainer = container

        try {
            windowManager?.addView(container, layoutParams)
        } catch (e: Exception) {
            e.printStackTrace()
            stopSelf()
            return
        }

        // Typewriter reveal of the message
        var charIndex = 0
        typewriterRunnable = object : Runnable {
            override fun run() {
                if (charIndex <= messageText.length) {
                    bubbleTextView.text = messageText.substring(0, charIndex)
                    charIndex++
                    handler.postDelayed(this, 50)
                }
            }
        }
        handler.post(typewriterRunnable!!)

        // Auto-dismiss after the duration
        dismissRunnable = Runnable {
            removeOverlay()
            stopSelf()
        }
        handler.postDelayed(dismissRunnable!, (durationSeconds * 1000).toLong())
    }

    private fun removeOverlay() {
        dismissRunnable?.let { handler.removeCallbacks(it) }
        typewriterRunnable?.let { handler.removeCallbacks(it) }
        overlayContainer?.let {
            try {
                windowManager?.removeView(it)
            } catch (e: Exception) {
                // Already removed
            }
        }
        overlayContainer = null
    }

    override fun onDestroy() {
        removeOverlay()
        super.onDestroy()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Lil Buddy Companion",
                NotificationManager.IMPORTANCE_MIN
            ).apply {
                description = "Runs brief peek-in companion overlays"
                setShowBadge(false)
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildSilentNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Lil Buddy")
            .setContentText("Companion is ready")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .build()
    }
}
