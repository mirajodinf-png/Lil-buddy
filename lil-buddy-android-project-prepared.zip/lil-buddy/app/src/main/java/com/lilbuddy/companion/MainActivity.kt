package com.lilbuddy.companion

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lilbuddy.companion.data.SettingsRepository
import com.lilbuddy.companion.model.CharacterId
import com.lilbuddy.companion.model.LilBuddyCharacter
import com.lilbuddy.companion.overlay.LilBuddyOverlayService
import com.lilbuddy.companion.scheduler.LilBuddyScheduler
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var settingsRepository: SettingsRepository
    private lateinit var scheduler: LilBuddyScheduler

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsRepository = SettingsRepository(this)
        scheduler = LilBuddyScheduler(this)

        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Color(0xFF4F46E5),
                    secondary = Color(0xFFF59E0B),
                    background = Color(0xFFF8FAFC)
                )
            ) {
                LilBuddyApp(
                    onRequestOverlayPermission = { requestOverlayPermission() },
                    onTriggerTestAppearance = { triggerTestAppearance() },
                    settingsRepository = settingsRepository,
                    scheduler = scheduler
                )
            }
        }
    }

    private fun requestOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val intent = Intent(
                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")
            )
            startActivity(intent)
        }
    }

    private fun triggerTestAppearance() {
        val intent = Intent(this, LilBuddyOverlayService::class.java).apply {
            action = LilBuddyOverlayService.ACTION_SHOW_TEST_BUDDY
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LilBuddyApp(
    onRequestOverlayPermission: () -> Unit,
    onTriggerTestAppearance: () -> Unit,
    settingsRepository: SettingsRepository,
    scheduler: LilBuddyScheduler
) {
    var selectedTab by remember { mutableStateOf(0) }
    val scope = rememberCoroutineScope()
    val settingsState by settingsRepository.settingsFlow.collectAsState(initial = null)

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🤍", modifier = Modifier.padding(end = 8.dp))
                        Text(
                            text = "Lil Buddy",
                            fontWeight = FontWeight.Bold,
                            fontSize = 20.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White
                )
            )
        },
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                    label = { Text("Home") }
                )
                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    icon = { Icon(Icons.Default.Face, contentDescription = "Buddies") },
                    label = { Text("Buddies") }
                )
                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    icon = { Icon(Icons.Default.Settings, contentDescription = "Settings") },
                    label = { Text("Settings") }
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color(0xFFF8FAFC))
        ) {
            val settings = settingsState
            if (settings != null) {
                when (selectedTab) {
                    0 -> MainHomeScreen(
                        settings = settings,
                        onTestClick = onTriggerTestAppearance,
                        onPermissionClick = onRequestOverlayPermission,
                        onToggleEnabled = { enabled ->
                            scope.launch {
                                settingsRepository.updateEnabled(enabled)
                                if (enabled) {
                                    scheduler.scheduleNextAppearance(settings.intervalMinutes)
                                } else {
                                    scheduler.cancelSchedule()
                                }
                            }
                        }
                    )
                    1 -> CharacterGalleryScreen(
                        selectedCharacterId = settings.selectedCharacterId,
                        onSelect = { charId ->
                            scope.launch {
                                settingsRepository.updateCharacter(charId)
                            }
                        }
                    )
                    2 -> SettingsTabScreen(
                        settings = settings,
                        onUpdateInterval = { min ->
                            scope.launch {
                                settingsRepository.updateInterval(min)
                                scheduler.scheduleNextAppearance(min)
                            }
                        },
                        onUpdateEdge = { edge ->
                            scope.launch { settingsRepository.updateEdge(edge) }
                        }
                    )
                }
            } else {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
fun MainHomeScreen(
    settings: com.lilbuddy.companion.data.LilBuddySettings,
    onTestClick: () -> Unit,
    onPermissionClick: () -> Unit,
    onToggleEnabled: (Boolean) -> Unit
) {
    val activeCharacter = LilBuddyCharacter.findById(settings.selectedCharacterId)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Active Status Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            shape = RoundedCornerShape(20.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = if (settings.isEnabled) "Lil Buddy is Active" else "Appearances Paused",
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp,
                            color = if (settings.isEnabled) Color(0xFF10B981) else Color(0xFF64748B)
                        )
                        Text(
                            text = "Every ${settings.intervalMinutes} minutes • ${activeCharacter.nameFa}",
                            fontSize = 13.sp,
                            color = Color(0xFF94A3B8)
                        )
                    }
                    Switch(
                        checked = settings.isEnabled,
                        onCheckedChange = onToggleEnabled
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Active Character Badge
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFF1F5F9))
                        .padding(12.dp)
                ) {
                    Text(
                        text = activeCharacter.prop ?: "🤍",
                        fontSize = 28.sp,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                    Column {
                        Text(
                            text = activeCharacter.nameFa,
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 15.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = activeCharacter.personalityFa,
                            fontSize = 12.sp,
                            color = Color(0xFF64748B),
                            maxLines = 2
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Big Test Appearance Button
        Button(
            onClick = onTestClick,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4F46E5))
        ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
            Text(text = "Test Peek Now (۸ ثانیه)", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedButton(
            onClick = onPermissionClick,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.padding(end = 8.dp))
            Text(text = "Overlay Permissions (مجوز نمایش)")
        }
    }
}

@Composable
fun CharacterGalleryScreen(
    selectedCharacterId: CharacterId,
    onSelect: (CharacterId) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(LilBuddyCharacter.ALL_CHARACTERS) { character ->
            val isSelected = character.id == selectedCharacterId
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSelect(character.id) },
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isSelected) Color(0xFFEEF2FF) else Color.White
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = character.prop ?: "🤍",
                        fontSize = 32.sp,
                        modifier = Modifier.padding(end = 16.dp)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = character.nameFa,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = Color(0xFF1E293B)
                        )
                        Text(
                            text = character.nameEn,
                            fontSize = 12.sp,
                            color = Color(0xFF94A3B8)
                        )
                        Text(
                            text = character.personalityFa,
                            fontSize = 13.sp,
                            color = Color(0xFF64748B),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    if (isSelected) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = "Selected",
                            tint = Color(0xFF4F46E5)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsTabScreen(
    settings: com.lilbuddy.companion.data.LilBuddySettings,
    onUpdateInterval: (Int) -> Unit,
    onUpdateEdge: (String) -> Unit
) {
    val intervals = listOf(5, 10, 15, 20, 25, 30, 45, 60)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text(
            text = "Appearance Interval (دقایق بین هر سرک کشیدن)",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color(0xFF334155)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            intervals.take(4).forEach { min ->
                FilterChip(
                    selected = settings.intervalMinutes == min,
                    onClick = { onUpdateInterval(min) },
                    label = { Text("$min m") }
                )
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Text(
            text = "Screen Edge (لبه صفحه)",
            fontWeight = FontWeight.Bold,
            fontSize = 15.sp,
            color = Color(0xFF334155)
        )

        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("LEFT" to "Left (چپ)", "RIGHT" to "Right (راست)", "RANDOM" to "Random (تصادفی)").forEach { (key, label) ->
                FilterChip(
                    selected = settings.preferredEdge == key,
                    onClick = { onUpdateEdge(key) },
                    label = { Text(label) }
                )
            }
        }
    }
}
