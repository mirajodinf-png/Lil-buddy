package com.lilbuddy.companion.data

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.lilbuddy.companion.model.CharacterId
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.Calendar

val Context.dataStore by preferencesDataStore(name = "lil_buddy_settings")

data class LilBuddySettings(
    val isEnabled: Boolean = true,
    val intervalMinutes: Int = 25,
    val displayDurationSeconds: Int = 8,
    val selectedCharacterId: CharacterId = CharacterId.SHY_FLOWER,
    val isRandomCharacter: Boolean = false,
    val preferredEdge: String = "RANDOM", // "LEFT", "RIGHT", "RANDOM"
    val bodyOrientation: String = "RANDOM", // "VERTICAL", "HORIZONTAL_HALF", "RANDOM"
    val animationIntensity: String = "NORMAL", // "SUBTLE", "NORMAL", "PLAYFUL"
    val decorativeEffectsEnabled: Boolean = true,
    val quietHoursEnabled: Boolean = false,
    val quietHoursStartHour: Int = 22,
    val quietHoursStartMinute: Int = 0,
    val quietHoursEndHour: Int = 8,
    val quietHoursEndMinute: Int = 0,
    val language: String = "fa" // "fa" for Persian, "en" for English
) {
    /**
     * Checks if current local time is within quiet hours.
     */
    fun isCurrentlyInQuietHours(calendar: Calendar = Calendar.getInstance()): Boolean {
        if (!quietHoursEnabled) return false
        val currentMinutes = calendar.get(Calendar.HOUR_OF_DAY) * 60 + calendar.get(Calendar.MINUTE)
        val startMinutes = quietHoursStartHour * 60 + quietHoursStartMinute
        val endMinutes = quietHoursEndHour * 60 + quietHoursEndMinute

        return if (startMinutes <= endMinutes) {
            currentMinutes in startMinutes until endMinutes
        } else {
            // Over midnight (e.g. 22:00 to 08:00)
            currentMinutes >= startMinutes || currentMinutes < endMinutes
        }
    }
}

class SettingsRepository(private val context: Context) {

    private object Keys {
        val IS_ENABLED = booleanPreferencesKey("is_enabled")
        val INTERVAL_MINUTES = intPreferencesKey("interval_minutes")
        val DISPLAY_DURATION = intPreferencesKey("display_duration_seconds")
        val SELECTED_CHARACTER = stringPreferencesKey("selected_character_id")
        val IS_RANDOM_CHARACTER = booleanPreferencesKey("is_random_character")
        val PREFERRED_EDGE = stringPreferencesKey("preferred_edge")
        val BODY_ORIENTATION = stringPreferencesKey("body_orientation")
        val ANIMATION_INTENSITY = stringPreferencesKey("animation_intensity")
        val DECORATIVE_EFFECTS = booleanPreferencesKey("decorative_effects")
        val QUIET_HOURS_ENABLED = booleanPreferencesKey("quiet_hours_enabled")
        val QUIET_START_HOUR = intPreferencesKey("quiet_start_hour")
        val QUIET_START_MINUTE = intPreferencesKey("quiet_start_minute")
        val QUIET_END_HOUR = intPreferencesKey("quiet_end_hour")
        val QUIET_END_MINUTE = intPreferencesKey("quiet_end_minute")
        val LANGUAGE = stringPreferencesKey("app_language")
    }

    val settingsFlow: Flow<LilBuddySettings> = context.dataStore.data.map { prefs ->
        LilBuddySettings(
            isEnabled = prefs[Keys.IS_ENABLED] ?: true,
            intervalMinutes = prefs[Keys.INTERVAL_MINUTES] ?: 25,
            displayDurationSeconds = prefs[Keys.DISPLAY_DURATION] ?: 8,
            selectedCharacterId = try {
                CharacterId.valueOf(prefs[Keys.SELECTED_CHARACTER] ?: CharacterId.SHY_FLOWER.name)
            } catch (e: Exception) {
                CharacterId.SHY_FLOWER
            },
            isRandomCharacter = prefs[Keys.IS_RANDOM_CHARACTER] ?: false,
            preferredEdge = prefs[Keys.PREFERRED_EDGE] ?: "RANDOM",
            bodyOrientation = prefs[Keys.BODY_ORIENTATION] ?: "RANDOM",
            animationIntensity = prefs[Keys.ANIMATION_INTENSITY] ?: "NORMAL",
            decorativeEffectsEnabled = prefs[Keys.DECORATIVE_EFFECTS] ?: true,
            quietHoursEnabled = prefs[Keys.QUIET_HOURS_ENABLED] ?: false,
            quietHoursStartHour = prefs[Keys.QUIET_START_HOUR] ?: 22,
            quietHoursStartMinute = prefs[Keys.QUIET_START_MINUTE] ?: 0,
            quietHoursEndHour = prefs[Keys.QUIET_END_HOUR] ?: 8,
            quietHoursEndMinute = prefs[Keys.QUIET_END_MINUTE] ?: 0,
            language = prefs[Keys.LANGUAGE] ?: "fa"
        )
    }

    suspend fun updateEnabled(enabled: Boolean) {
        context.dataStore.edit { it[Keys.IS_ENABLED] = enabled }
    }

    suspend fun updateInterval(minutes: Int) {
        context.dataStore.edit { it[Keys.INTERVAL_MINUTES] = minutes }
    }

    suspend fun updateCharacter(id: CharacterId, isRandom: Boolean = false) {
        context.dataStore.edit {
            it[Keys.SELECTED_CHARACTER] = id.name
            it[Keys.IS_RANDOM_CHARACTER] = isRandom
        }
    }

    suspend fun updateEdge(edge: String) {
        context.dataStore.edit { it[Keys.PREFERRED_EDGE] = edge }
    }

    suspend fun updateQuietHours(enabled: Boolean, startH: Int, startM: Int, endH: Int, endM: Int) {
        context.dataStore.edit {
            it[Keys.QUIET_HOURS_ENABLED] = enabled
            it[Keys.QUIET_START_HOUR] = startH
            it[Keys.QUIET_START_MINUTE] = startM
            it[Keys.QUIET_END_HOUR] = endH
            it[Keys.QUIET_END_MINUTE] = endM
        }
    }
}
