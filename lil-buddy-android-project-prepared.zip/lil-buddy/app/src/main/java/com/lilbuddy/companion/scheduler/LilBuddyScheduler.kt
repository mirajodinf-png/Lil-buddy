package com.lilbuddy.companion.scheduler

import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.lilbuddy.companion.data.SettingsRepository
import com.lilbuddy.companion.overlay.LilBuddyOverlayService
import kotlinx.coroutines.flow.first
import java.util.concurrent.TimeUnit

class LilBuddyScheduler(private val context: Context) {

    companion object {
        const val WORK_NAME = "lil_buddy_periodic_appearance"
    }

    fun scheduleNextAppearance(intervalMinutes: Int) {
        val safeInterval = intervalMinutes.coerceAtLeast(15).toLong() // Android WorkManager minimum is 15 minutes

        val constraints = Constraints.Builder()
            .setRequiresBatteryNotLow(false)
            .build()

        val periodicWorkRequest = PeriodicWorkRequestBuilder<LilBuddyWorker>(
            safeInterval, TimeUnit.MINUTES,
            5, TimeUnit.MINUTES // Flex interval
        )
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            WORK_NAME,
            ExistingPeriodicWorkPolicy.UPDATE,
            periodicWorkRequest
        )
    }

    fun cancelSchedule() {
        WorkManager.getInstance(context).cancelUniqueWork(WORK_NAME)
    }
}

class LilBuddyWorker(
    private val appContext: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(appContext, workerParams) {

    override suspend fun doWork(): Result {
        val settingsRepo = SettingsRepository(appContext)
        val settings = settingsRepo.settingsFlow.first()

        // 1. Verify feature is enabled
        if (!settings.isEnabled) {
            return Result.success()
        }

        // 2. Check quiet-hours setting
        if (settings.isCurrentlyInQuietHours()) {
            return Result.success()
        }

        // 3. Check overlay permission
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(appContext)) {
            return Result.success()
        }

        // 4. Trigger the overlay service
        val intent = Intent(appContext, LilBuddyOverlayService::class.java).apply {
            action = LilBuddyOverlayService.ACTION_SHOW_SCHEDULED_BUDDY
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            appContext.startForegroundService(intent)
        } else {
            appContext.startService(intent)
        }

        return Result.success()
    }
}
