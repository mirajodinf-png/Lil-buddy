package com.lilbuddy.companion.model

/**
 * Lil Buddy Character and Animation State definitions.
 * Strict compliance with the Original Character Engine:
 * - White, simple, rounded silhouette
 * - Thick black outlines
 * - Half-lidded deadpan eyes
 * - Distinctive long curved facial line
 * - 17 deterministic animation states
 */
enum class CharacterId {
    ORIGINAL_BUDDY,
    SHY_FLOWER,
    COOL_BUDDY,
    SLEEPY_BUDDY,
    MISCHIEF_BUDDY,
    HAPPY_BUDDY,
    CURIOUS_BUDDY,
    DRAMATIC_BUDDY,
    TINY_GHOST
}

enum class CharacterAnimationState {
    IDLE,
    ATTENTIVE,
    LOOKING_LEFT,
    LOOKING_RIGHT,
    LOOKING_UP,
    LOOKING_DOWN,
    BLINK,
    CURIOUS,
    CONFUSED,
    PLEASED,
    DISAPPOINTED,
    SURPRISED,
    THINKING,
    SPEAKING,
    LISTENING,
    CELEBRATING,
    RETURNING_TO_IDLE
}

enum class BubbleStyle {
    ROUNDED,
    THOUGHT,
    COMIC_BURST,
    CELEBRATORY,
    DREAMY,
    GENTLE
}

data class LilBuddyCharacter(
    val id: CharacterId,
    val nameEn: String,
    val nameFa: String,
    val personalityEn: String,
    val personalityFa: String,
    val defaultState: CharacterAnimationState = CharacterAnimationState.IDLE,
    val prop: String? = null,
    val baseColorHex: String = "#FFFFFF",
    val outlineColorHex: String = "#0F172A",
    val defaultEdge: String = "RANDOM"
) {
    companion object {
        val ALL_CHARACTERS = listOf(
            LilBuddyCharacter(
                id = CharacterId.ORIGINAL_BUDDY,
                nameEn = "Lil Buddy (Original)",
                nameFa = "دوست کوچولو (اصلی)",
                personalityEn = "Authentic original white blob character with thick black outlines, half-lidded deadpan eyes, and distinctive facial curve.",
                personalityFa = "کاراکتر اصیل با سیلوئت سفید، خطوط مشکی ۴ پیکسل، پلک نیمه‌باز بی‌تفاوت و خط منحنی صورت.",
                defaultState = CharacterAnimationState.IDLE,
                prop = "🤍"
            ),
            LilBuddyCharacter(
                id = CharacterId.SHY_FLOWER,
                nameEn = "Shy Flower Buddy",
                nameFa = "دوست خجالتی با گل",
                personalityEn = "Shy, affectionate, bashful. Peeks out, retreats slightly, then slowly presents a tiny rose.",
                personalityFa = "خجالتی و بامحبت. سرک می‌کشه، یکم عقب می‌ره و بعد آروم با یه شاخه گل رز سرخ میاد جلو.",
                defaultState = CharacterAnimationState.CURIOUS,
                prop = "🌹"
            ),
            LilBuddyCharacter(
                id = CharacterId.COOL_BUDDY,
                nameEn = "Cool Buddy",
                nameFa = "دوست خفن",
                personalityEn = "Confident, relaxed, and stylish with tiny dark sunglasses.",
                personalityFa = "خونسرد، با اعتمادبه‌نفس و عینک آفتابی مشکی.",
                defaultState = CharacterAnimationState.ATTENTIVE,
                prop = "🕶️"
            ),
            LilBuddyCharacter(
                id = CharacterId.SLEEPY_BUDDY,
                nameEn = "Sleepy Buddy",
                nameFa = "دوست خواب‌آلود",
                personalityEn = "Calm, slow, and tired. Peeks slowly, blinks droopy eyes, and gently drifts off.",
                personalityFa = "آرام، خواب‌آلود و ملایم. آروم سرک می‌کشه، پلک می‌زنه و کم‌کم محو می‌شه.",
                defaultState = CharacterAnimationState.BLINK,
                prop = "💤"
            ),
            LilBuddyCharacter(
                id = CharacterId.MISCHIEF_BUDDY,
                nameEn = "Mischief Buddy",
                nameFa = "دوست شیطون",
                personalityEn = "Cheeky and silly. Pops out unexpectedly, makes a funny face, then darts away.",
                personalityFa = "شیطون و پرانرژی. یهویی می‌پره بیرون، شکلک درمیاره و سریع قایم می‌شه.",
                defaultState = CharacterAnimationState.SURPRISED,
                prop = "😜"
            ),
            LilBuddyCharacter(
                id = CharacterId.HAPPY_BUDDY,
                nameEn = "Happy Buddy",
                nameFa = "دوست خوشحال",
                personalityEn = "Cheerful and encouraging. Bounces gently and raises tiny arms in celebration.",
                personalityFa = "پر از انرژی مثبت و خوشحال. آروم بالا و پایین می‌پره و دستاش رو بالا می‌بره.",
                defaultState = CharacterAnimationState.CELEBRATING,
                prop = "✨"
            ),
            LilBuddyCharacter(
                id = CharacterId.CURIOUS_BUDDY,
                nameEn = "Curious Buddy",
                nameFa = "دوست کنجکاو",
                personalityEn = "Surprised and intrigued. Peeks around the edge, glances left and right with wide eyes.",
                personalityFa = "کنجکاو و شگفت‌زده. دور و بر رو نگاه می‌کنه تا ببینه چه خبره.",
                defaultState = CharacterAnimationState.LOOKING_LEFT,
                prop = "👀"
            ),
            LilBuddyCharacter(
                id = CharacterId.DRAMATIC_BUDDY,
                nameEn = "Dramatic Buddy",
                nameFa = "دوست نمایشی",
                personalityEn = "Theatrical and exaggerated. Makes a dramatic entrance pause and an artistic pose.",
                personalityFa = "عاشق نمایش و ژست‌های اغراق‌آمیز با یه مکث تئاتری جذاب.",
                defaultState = CharacterAnimationState.THINKING,
                prop = "⭐"
            ),
            LilBuddyCharacter(
                id = CharacterId.TINY_GHOST,
                nameEn = "Tiny Ghost Buddy",
                nameFa = "روح کوچولوی مهربون",
                personalityEn = "Playful, harmless, slightly mysterious. Floats in softly with a wavy tail and fades peacefully.",
                personalityFa = "روح کوچولو، بی‌آزار و دوست‌داشتنی. نرم شناور می‌شه و آروم محو می‌شه.",
                defaultState = CharacterAnimationState.PLEASED,
                prop = "👻"
            )
        )

        fun findById(id: CharacterId): LilBuddyCharacter {
            return ALL_CHARACTERS.firstOrNull { it.id == id } ?: ALL_CHARACTERS.first()
        }
    }
}
