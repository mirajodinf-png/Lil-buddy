# Lil Buddy (دوست کوچولو) — Native Android Character Companion

A playful, lightweight Android application featuring tiny, expressive, hand-drawn cartoon characters that occasionally peek out from the edge of your phone screen for an 8-second delightful surprise.

## Key Features
- **Native Android WindowManager Overlay**: Uses `TYPE_APPLICATION_OVERLAY` to appear over other apps without blocking background touches.
- **8 Expressive Hand-Drawn Characters**: Shy Flower (rose & blush), Cool Buddy (sunglasses), Sleepy Buddy (slow crawl & blink), Mischief Buddy (silly face & pop), Happy Buddy (bounce & raised arms), Curious Buddy (glances left & right), Dramatic Buddy (theatrical star pause), and Tiny Ghost Buddy (floating scallop tail).
- **Typewriter Speech Bubble**: Smooth character-by-character reveal with Unicode grapheme-safe emoji support.
- **Bilingual Support**: Persian (Right-to-Left) and English (Left-to-Right).
- **Quiet Hours**: Respects custom quiet periods (e.g., 22:00 to 08:00) so you sleep or focus uninterrupted.
- **Boot Recovery**: Restores schedule upon device reboot via `BootReceiver`.
- **100% Offline & Private**: Zero internet permissions (`android.permission.INTERNET` is omitted), zero analytics, zero data collection.
- **Soundless**: Silent by design so it never disrupts meetings or calls.

## How to Open and Run in Android Studio
1. Download or extract this folder.
2. Open **Android Studio** (Hedgehog, Iguana, Koala, or Ladybug).
3. Select **File > Open...** and select this `lil-buddy` directory.
4. Let Gradle sync dependencies.
5. Connect your Android phone via USB (with USB Debugging enabled in Developer Options) or start an Android Virtual Device (AVD).
6. Click the green **Run (▶)** button.
7. On your phone, tap **"Overlay Permissions"** and toggle ON **"Display over other apps"** for Lil Buddy.
8. Tap **"Test Peek Now"** to see your companion visit!

## Command Line Build
```bash
./gradlew assembleDebug
```
The generated APK will be located at `app/build/outputs/apk/debug/app-debug.apk`.
